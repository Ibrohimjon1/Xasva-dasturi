package com.example.ibrohimjon.xasva;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;


public class MyDataBase extends SQLiteOpenHelper {

    public MyDataBase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public void queryData(String sql) {
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }

    public Cursor getData(String sql) {
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }

    public void insert_shahar(String name, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, name);
        statement.executeInsert();
    }

    public void Insert_goza(String sana, String kop_yillik, String foydali, String xaqiq, String yig, String goza, String joy_nomi, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, sana);
        statement.bindString(2, kop_yillik);
        statement.bindString(3, foydali);
        statement.bindString(4, xaqiq);
        statement.bindString(5, yig);
        statement.bindString(6, goza);
        statement.bindString(7, joy_nomi);
        statement.executeInsert();
    }

    public void updateData_viloyat_nomi(String sql, String viloyat_nomi, int id) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, viloyat_nomi);
        statement.bindDouble(2, (double) id);

        statement.execute();
        database.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
