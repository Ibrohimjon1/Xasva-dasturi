package com.example.ibrohimjon.xasva;

public class Viloyat_list {

    String viloyat_nomi;
    int tartib, viloyat;

    public Viloyat_list(String viloyat_nomi, int tartib, int viloyat) {
        this.viloyat_nomi = viloyat_nomi;
        this.tartib = tartib;
        this.viloyat = viloyat;
    }

    public int getViloyat() {
        return viloyat;
    }

    public void setViloyat(int viloyat) {
        this.viloyat = viloyat;
    }

    public String getViloyat_nomi() {
        return viloyat_nomi;
    }

    public void setViloyat_nomi(String joy_nomi) {
        this.viloyat_nomi = joy_nomi;
    }

    public int getTartib() {
        return tartib;
    }

    public void setTartib(int tartib) {
        this.tartib = tartib;
    }
}
