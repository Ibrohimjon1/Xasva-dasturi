package com.example.ibrohimjon.xasva;


public class Goza_joy_list {

    String joy_nomi;
    int tartib;

    public Goza_joy_list(String joy_nomi, int tartib) {
        this.joy_nomi = joy_nomi;
        this.tartib = tartib;
    }

    public String getJoy_nomi() {
        return joy_nomi;
    }

    public void setJoy_nomi(String joy_nomi) {
        this.joy_nomi = joy_nomi;
    }

    public int getTartib() {
        return tartib;
    }

    public void setTartib(int tartib) {
        this.tartib = tartib;
    }
}
