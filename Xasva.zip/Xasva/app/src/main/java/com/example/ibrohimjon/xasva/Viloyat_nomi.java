package com.example.ibrohimjon.xasva;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Viloyat_nomi extends AppCompatActivity {

    Viloyat_adapter adapter = null;
    ListView list_view;
    ArrayList<Viloyat_list> list;
    EditText edt_viloyat_nomi;
    ImageView btn_viloyat_add;
    ImageButton btn_viloyat_filter;
    int a = 2;
    int[] images_btn = {R.drawable.sort_asc, R.drawable.sort_desc};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viloyat_nomi_royh);

        list = new ArrayList<>();
        list_view = (ListView) findViewById(R.id.list_view_viloyat_nomi);
        edt_viloyat_nomi = (EditText) findViewById(R.id.edt_viloyat_nomi);
        btn_viloyat_add = (ImageView) findViewById(R.id.btn_viloyat_add);
        btn_viloyat_filter = (ImageButton) findViewById(R.id.btn_viloyat_filter);

        edt_viloyat_nomi.setHint("Viloyat nomi");


        adapter = new Viloyat_adapter(this, R.layout.viloyat_nomi_items, list);
        list_view.setAdapter(adapter);

        try {
            int son = getdata("SELECT * FROM VILOYAT ORDER BY viloyat ASC");
            if (son == 0) {
                Toast.makeText(getApplicationContext(), "Viloyat nomida hech nima yo'q!", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        list_view.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                CharSequence[] items = {"O'zgartirish", "O'chirish"};
                AlertDialog.Builder dialog = new AlertDialog.Builder(Viloyat_nomi.this);
                final TextView txt_viloyat = (TextView) view.findViewById(R.id.txt_viloyat_nomi);
                TextView txt_id = (TextView) view.findViewById(R.id.txt_viloyat_id);
                final int id3 = Integer.parseInt(txt_id.getText().toString());
                dialog.setTitle("Tanlang");
                dialog.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {

                        if (item == 0) {
                            //Update
                            showDialog_Update(Viloyat_nomi.this, id3, txt_viloyat.getText().toString().trim());
                        } else {
                            // delete
                            showDialogDelete_for_one(id3);
                        }
                    }
                });
                dialog.show();
                return true;
            }
        });

        btn_viloyat_filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (a == 1) {
                    getdata("SELECT * FROM VILOYAT ORDER BY viloyat ASC");
                    btn_viloyat_filter.setImageResource(images_btn[1]);
                    a = 2;
                } else if (a == 2) {
                    getdata("SELECT * FROM VILOYAT ORDER BY viloyat DESC");
                    btn_viloyat_filter.setImageResource(images_btn[0]);
                    a = 1;
                }
            }
        });

        btn_viloyat_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edt_viloyat_nomi.getText().toString().equals("")) {
                    String add = edt_viloyat_nomi.getText().toString().trim();
                    try {
                        String sql = "INSERT INTO VILOYAT VALUES (NULL, ?)";
                        Asosiy_oyna.myDataBase.insert_shahar(add, sql);
                        edt_viloyat_nomi.setText("");
                        getdata("SELECT * FROM VILOYAT ORDER BY viloyat ASC");
                        Toast.makeText(getApplicationContext(), "Muvaffaqqiyatli saqlandi!", Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Saqlanishda xatolik boldi!!!", Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Iltimos Viloyat nomini kiriting!", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    private void showDialogDelete_for_one(final int id) {
        AlertDialog.Builder dialogDelete = new AlertDialog.Builder(Viloyat_nomi.this);
        dialogDelete.setTitle("Ogohlantirish!!!");
        dialogDelete.setMessage("Haqiqatdan ham ushbu ma'lumotni o'chirmoqchimisiz?");
        dialogDelete.setPositiveButton("Ha", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                try {
                    Asosiy_oyna.myDataBase.insert_shahar(String.valueOf(id), "DELETE FROM VILOYAT WHERE Id = ?");
                    Toast.makeText(getApplicationContext(), "Muvaffaqqiyatli o'chirildi!!!", Toast.LENGTH_SHORT).show();
                } catch (Exception error) {
                    error.printStackTrace();
                }
                getdata("SELECT * FROM VILOYAT ORDER BY viloyat ASC");
            }
        });

        dialogDelete.setNegativeButton("Yo'q", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialogDelete.show();
    }

    private void showDialog_Update(Activity activity, final int id, final String viloyat_nomi) {

        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.viloyat_nomi_update);
        dialog.setCancelable(false);
        dialog.setTitle("O'zgartirish");

        Button btn_kirim_back = (Button) dialog.findViewById(R.id.btn_vil_upd_back);
        Button btn_kirim_update = (Button) dialog.findViewById(R.id.btn_vil_upd_ok);
        TextView txt_kirim_upd = (TextView) dialog.findViewById(R.id.txt_viloyat_upd_nom);
        final EditText edt_kirim_upd = (EditText) dialog.findViewById(R.id.edt_viloyat_update);

        edt_kirim_upd.setHint("Viloyat nomi");
        edt_kirim_upd.setText(viloyat_nomi);
        edt_kirim_upd.setSelection(viloyat_nomi.length());
        txt_kirim_upd.setText(viloyat_nomi);

        txt_kirim_upd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt_kirim_upd.setText(viloyat_nomi);
                edt_kirim_upd.setSelection(viloyat_nomi.length());
            }
        });

        btn_kirim_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        btn_kirim_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (!edt_kirim_upd.getText().toString().equals("")) {
                        Asosiy_oyna.myDataBase.updateData_viloyat_nomi("UPDATE VILOYAT SET viloyat = ? WHERE Id = ?", edt_kirim_upd.getText().toString().trim(), id);

                        Toast.makeText(getApplicationContext(), "Muvaffaqqiyatli o'zgartirildi!", Toast.LENGTH_SHORT).show();
                        getdata("SELECT * FROM VILOYAT ORDER BY viloyat ASC");
                        dialog.dismiss();
                    } else {
                        Toast.makeText(getApplicationContext(), "Iltimos Viloyat nomini kiriting!", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        int width = activity.getResources().getDisplayMetrics().widthPixels;
        int height = (int) (activity.getResources().getDisplayMetrics().heightPixels * 0.5);

        dialog.getWindow().setLayout(width, height);
        dialog.show();
    }

    public int getdata(String sql) {
        Cursor cursor = Asosiy_oyna.myDataBase.getData(sql);

        list.clear();
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                String viloyat_nomi = cursor.getString(1);
                int id = cursor.getInt(0);
                list.add(new Viloyat_list(viloyat_nomi, id, 1));
            } while (cursor.moveToNext());
            adapter.notifyDataSetChanged();
            return 1;
        }else {
            list.clear();
            adapter.notifyDataSetChanged();
            return 0;
        }
    }
}
