package com.example.ibrohimjon.xasva;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Ortacha_xarorat extends AppCompatActivity {

    Button btn_back, btn_add;
    EditText edt_goza, edt_kuzgi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ortacha_xarorat_activity);

        btn_add = (Button) findViewById(R.id.btn_xar_add);
        btn_back = (Button) findViewById(R.id.btn_xar_back);
        edt_goza = (EditText) findViewById(R.id.edt_kop_xarorar_ort);
        edt_kuzgi = (EditText) findViewById(R.id.edt_kuz_xarorat_ort);

        SharedPreferences preferences = getSharedPreferences("ortacha_xarorat", Context.MODE_PRIVATE);

        String goza = preferences.getString("goza","");
        String kuzgi = preferences.getString("kuzgi","");

        edt_goza.setText(goza);
        edt_kuzgi.setText(kuzgi);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences preferences = getSharedPreferences("ortacha_xarorat", Context.MODE_PRIVATE);

                SharedPreferences.Editor editor = preferences.edit();
//                editor.putString("goza", edt_goza.getText().toString().trim());
                editor.putString("kuzgi", edt_kuzgi.getText().toString().trim());
                editor.apply();
                Toast.makeText(getApplicationContext(),"O'rtacha haroratlar saqlandi!",Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }
}
