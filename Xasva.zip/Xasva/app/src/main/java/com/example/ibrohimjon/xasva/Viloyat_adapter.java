package com.example.ibrohimjon.xasva;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Viloyat_adapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<Viloyat_list> viloyat_list;
    int [] images = {R.drawable.viloyat1,R.drawable.shahar1,R.drawable.kocha1};

    public Viloyat_adapter(Context context, int layout, ArrayList<Viloyat_list> viloyat_list) {
        this.context = context;
        this.layout = layout;
        this.viloyat_list = viloyat_list;
    }

    @Override
    public int getCount() {
        return viloyat_list.size();
    }

    @Override
    public Object getItem(int position) {
        return viloyat_list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txt_viloyat_nomi, txt_viloyat_id;
        ImageView imageView;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        int viloyat;
        View row = view;
        ViewHolder holder = new ViewHolder();

        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout, null);

            holder.imageView = (ImageView) row.findViewById(R.id.img_viloyat_rasm);
            holder.txt_viloyat_nomi = (TextView) row.findViewById(R.id.txt_viloyat_nomi);
            holder.txt_viloyat_id = (TextView) row.findViewById(R.id.txt_viloyat_id);

            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }

        Viloyat_list viloyat_list1 = viloyat_list.get(position);

        holder.txt_viloyat_nomi.setText(viloyat_list1.getViloyat_nomi());
        holder.txt_viloyat_id.setText(String.valueOf(viloyat_list1.getTartib()));
        viloyat = viloyat_list1.getViloyat();

        if (viloyat == 1){
            holder.imageView.setImageResource(images[0]);
        } else if (viloyat == 2) {
            holder.imageView.setImageResource(images[1]);
        } else if (viloyat == 3) {
            holder.imageView.setImageResource(images[2]);
        }

        return row;
    }
}
