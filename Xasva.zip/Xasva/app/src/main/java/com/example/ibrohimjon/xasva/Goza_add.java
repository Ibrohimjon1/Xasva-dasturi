package com.example.ibrohimjon.xasva;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.NotificationCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Goza_add extends AppCompatActivity {

    ImageView btn_add;
    GridLayout gridLayout;
    int year_x, month_x, day_x;
    int sana = 1;
    int indexx = 2;
    HorizontalScrollView scrollView;
    ArrayList<TextView> all_sana = new ArrayList<>();
    ArrayList<TextView> all_eskilar = new ArrayList<>();
    String string12 = "";
    TextView txt_saaana;
    TextView txt_sana_asosiy, txt_kop_asosiy, txt_foy_asosiy, txt_xaq_asosiy,
            txt_yig_asosiy, txt_goza_asosiy, txt_goza_add_joy;
    Button btn_goza_saqlash;
    String joy_nomi_intent = "";
    int yangi_add = 1;
    int qoshilgan_soni = 0;
    View row_asosiy;
    String oxir_yig = "", oxir_foy = "";
    int ayrilgan_soni = 0;
    float ayir;
    int id = 100;
    private static Uri alarmSound;


    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goza_add);


        txt_goza_add_joy = (TextView) findViewById(R.id.txt_goza_add_joy);
        gridLayout = (GridLayout) findViewById(R.id.gridlayout);
        txt_sana_asosiy = (TextView) findViewById(R.id.txt_sana_asosiy);
        btn_add = (ImageView) findViewById(R.id.btn_savdo_add_p);
        scrollView = (HorizontalScrollView) findViewById(R.id.scrollView);
        txt_kop_asosiy = (TextView) findViewById(R.id.txt_kop_asosiy);
        txt_foy_asosiy = (TextView) findViewById(R.id.txt_foy_asosiy);
        txt_xaq_asosiy = (TextView) findViewById(R.id.txt_xaq_asosiy);
        txt_yig_asosiy = (TextView) findViewById(R.id.txt_yig_asosiy);
        txt_goza_asosiy = (TextView) findViewById(R.id.txt_goza_asosiy);
        btn_goza_saqlash = (Button) findViewById(R.id.btn_goza_saqlash);

        alarmSound = RingtoneManager
                .getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);


        Intent intent = getIntent();
        joy_nomi_intent = intent.getExtras().getString("joy_nomi");
        assert joy_nomi_intent != null;
        if (joy_nomi_intent.equals("")) {
            yangi_add = 1;
            final Calendar calendar = Calendar.getInstance();
            year_x = calendar.get(Calendar.YEAR);
            month_x = calendar.get(Calendar.MONTH);
            day_x = calendar.get(Calendar.DAY_OF_MONTH);

            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
            string12 = format.format(calendar.getTime());
            txt_sana_asosiy.setText(string12);
            String viloyat = intent.getExtras().getString("viloyat");
            String shahar = intent.getExtras().getString("shahar");
            String kocha = intent.getExtras().getString("kocha");
            txt_goza_add_joy.setText(viloyat + "/" + shahar + "/" + kocha);
        } else {
            txt_goza_add_joy.setText(joy_nomi_intent);
            gridLayout.removeViewAt(1);
            final Calendar calendar = Calendar.getInstance();
            year_x = calendar.get(Calendar.YEAR);
            month_x = calendar.get(Calendar.MONTH);
            day_x = calendar.get(Calendar.DAY_OF_MONTH);
            indexx = 1;
            Toldirish();
            yangi_add = 0;
        }

        SharedPreferences preferences = getSharedPreferences("ortacha_xarorat", Context.MODE_PRIVATE);
        String goza = preferences.getString("goza", "");
        if (!goza.equals("")) {
            ayir = Float.valueOf(goza);
        }
        txt_sana_asosiy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_saaana = txt_sana_asosiy;
                Sana_tanlash();
            }
        });

        txt_kop_asosiy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_OnClick(txt_kop_asosiy, 5);
            }
        });

        txt_xaq_asosiy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_OnClick(txt_xaq_asosiy, 8);
            }
        });

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Qoshish();
            }
        });
    }

    public void txt_OnClick(TextView view, int qator) {
        String str = view.getText().toString();
        int id_txt = view.getId();

        showDialog_Update(Goza_add.this, str, view, id_txt, qator);

    }

    public void txt_long_click(TextView textView, int qatot) {
        if (yangi_add == 0) {
            int id_txt = textView.getId();
            TextView textView1 = null;
            if (qatot == 1) {
                textView1 = all_eskilar.get(id_txt - 2);
            } else if (qatot == 2) {
                textView1 = all_eskilar.get(id_txt - 3);
            } else if (qatot == 3) {
                textView1 = all_eskilar.get(id_txt - 4);
            } else if (qatot == 4) {
                textView1 = all_eskilar.get(id_txt - 5);
            } else if (qatot == 5) {
                textView1 = all_eskilar.get(id_txt - 6);
            } else if (qatot == 6) {
                textView1 = all_eskilar.get(id_txt - 7);
            }
            int farq = id_txt / 7;
            if ((farq + 2) == indexx) {
                assert textView1 != null;
                String qator_id = textView1.getText().toString();
                showDialogDelete_for_one(qator_id, (farq + 2));
            } else {
                Toast.makeText(getApplicationContext(), "Iltimos oxirgi ma'lumotni o'chiring!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showDialogDelete_for_one(final String id, final int indeeex) {
        AlertDialog.Builder dialogDelete = new AlertDialog.Builder(Goza_add.this);
        dialogDelete.setTitle("Ogohlantirish!!!");
        dialogDelete.setMessage("Haqiqatdan ham ushbu ma'lumotni o'chirmoqchimisiz?");
        dialogDelete.setPositiveButton("Ha", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                try {
                    Asosiy_oyna.myDataBase.insert_shahar(id, "DELETE FROM GOZA WHERE Id = ?");
                    Toast.makeText(getApplicationContext(), "Muvaffaqqiyatli o'chirildi!!!", Toast.LENGTH_SHORT).show();
                } catch (Exception error) {
                    error.printStackTrace();
                }
                gridLayout.removeViewAt(indeeex - 1);
                Cursor cursor_goza = Asosiy_oyna.myDataBase.getData("SELECT * FROM GOZA WHERE joy_nomi LIKE '" + joy_nomi_intent.replace("'", "''") + "' ORDER BY DATE(sana) ASC");
                if (cursor_goza.getCount() != 0) {
                    cursor_goza.moveToLast();
                    string12 = cursor_goza.getString(1);
                    oxir_foy = cursor_goza.getString(3);
                    oxir_yig = cursor_goza.getString(5);
                }
                int sons = all_eskilar.size() - 1;
                for (int i = 1; i < 8; i++) {
                    all_eskilar.remove(sons);
                    sons--;
                    sana--;
                    qoshilgan_soni--;
                }
                ayrilgan_soni++;
                indexx -= 1;
            }
        });

        dialogDelete.setNegativeButton("Yo'q", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialogDelete.show();
    }

    private void showDialogDelete_yangi() {
        AlertDialog.Builder dialogDelete = new AlertDialog.Builder(Goza_add.this);
        dialogDelete.setTitle("Ogohlantirish!!!");
        dialogDelete.setMessage("Haqiqatdan ham ushbu ma'lumotni o'chirmoqchimisiz?");
        dialogDelete.setPositiveButton("Ha", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                gridLayout.removeViewAt(indexx - 1);
                string12 = Oldingi_sana(string12);
                int soni = sana - all_eskilar.size() - 2;
                for (int i = 1; i < 7; i++) {
                    all_sana.remove(soni);
                    soni--;
                    sana--;
                }

                indexx -= 1;
            }
        });

        dialogDelete.setNegativeButton("Yo'q", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialogDelete.show();
    }

    public void txt_long_click_yangi(TextView textView, int qator) {
        if (yangi_add == 0) {
            int id_txt = textView.getId();
            int farq = id_txt / 6;
            if ((farq + 2) == indexx) {
                showDialogDelete_yangi();
            } else {
                String vaa = String.valueOf(farq) + "  " + indexx;
                Log.d("xatolik", vaa);
                Toast.makeText(getApplicationContext(), "Iltimos oxirgi ma'lumotni o'chiring!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // tepada menu tugmalari qo'shish
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_add) {
            Saqlash();
        }

        return super.onOptionsItemSelected(item);
    }

    public void Toldirish() {
        try {
            Cursor cursor_goza = Asosiy_oyna.myDataBase.getData("SELECT * FROM GOZA WHERE joy_nomi LIKE '" + joy_nomi_intent.replace("'", "''") + "' ORDER BY DATE(sana) ASC");
            if (cursor_goza.getCount() != 0) {
                cursor_goza.moveToFirst();
                do {
                    int id = cursor_goza.getInt(0);
                    String sana = cursor_goza.getString(1);
                    String kop = cursor_goza.getString(2);
                    String foy = cursor_goza.getString(3);
                    String xaq = cursor_goza.getString(4);
                    String yig = cursor_goza.getString(5);
                    String goza = cursor_goza.getString(6);

                    Qoshish_update(id, sana, kop, foy, xaq, yig, goza);

                } while (cursor_goza.moveToNext());

                cursor_goza.moveToLast();
                qoshilgan_soni = cursor_goza.getCount() * 7;
                //bazadagi oxirgi malumotni olamiz
                string12 = cursor_goza.getString(1);
                oxir_foy = cursor_goza.getString(3);
                oxir_yig = cursor_goza.getString(5);
            }
        } catch (Exception error) {
            error.printStackTrace();

        }
    }

    public void Saqlash() {

        String joy_nomi = txt_goza_add_joy.getText().toString().trim();
        String sql = "INSERT INTO GOZA VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)";

        if (!txt_kop_asosiy.getText().toString().equals("") || !txt_xaq_asosiy.getText().toString().equals("")) {
            String sana = txt_sana_asosiy.getText().toString().trim();
            String kop_yillik = txt_kop_asosiy.getText().toString().trim();
            String foydali = txt_foy_asosiy.getText().toString().trim();
            String xaqiq = txt_xaq_asosiy.getText().toString().trim();
            String yigin = txt_yig_asosiy.getText().toString().trim();
            String goza = txt_goza_asosiy.getText().toString().trim();

            try {
                Asosiy_oyna.myDataBase.Insert_goza(sana, kop_yillik, foydali, xaqiq, yigin, goza, joy_nomi, sql);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            if (all_sana.size() > 0) {
                int a = (all_sana.size() + 1) / 6;
                int id = 0;
                for (int i = 0; i < a; i++) {
                    TextView txt_sana = all_sana.get(id);
                    id++;
                    TextView txt_kop = all_sana.get(id);
                    id++;
                    TextView txt_foy = all_sana.get(id);
                    id++;
                    TextView txt_xaq = all_sana.get(id);
                    id++;
                    TextView txt_yig = all_sana.get(id);
                    id++;
                    TextView txt_goza = all_sana.get(id);
                    id++;

                    String str_sana = txt_sana.getText().toString().trim();
                    String str_kop = txt_kop.getText().toString().trim();
                    String str_foy = txt_foy.getText().toString().trim();
                    String str_xaq = txt_xaq.getText().toString().trim();
                    String str_yig = txt_yig.getText().toString().trim();
                    String str_goza = txt_goza.getText().toString().trim();
                    if (!str_kop.equals("") && !str_xaq.equals("")) {
                        Asosiy_oyna.myDataBase.Insert_goza(str_sana, str_kop, str_foy, str_xaq, str_yig, str_goza, joy_nomi, sql);
                    }
                }
                all_sana.clear();
            }

            Toast.makeText(getApplicationContext(), "Muvaffaqqiyatli saqlandi!", Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception error) {
            error.printStackTrace();
            Toast.makeText(getApplicationContext(), "Saqlanishda xatolik bo'ldi!!!", Toast.LENGTH_SHORT).show();
        }

    }

    private void showDialog_Update(Activity activity, final String kirim_nomi, final TextView textView, final int kegingi, final int qator) {
//        final float[] faa = new float[1];
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.raqam_oyna);
        dialog.setCancelable(false);
        dialog.setTitle("O'zgartirish");

        TextView txt_oyna_upd = (TextView) dialog.findViewById(R.id.txt_oyna_nom);

        if (qator == 1 || qator == 5) {
            txt_oyna_upd.setText("Ko'p yillik o'rtacha harorat");
        } else if (qator == 2 || qator == 8) {
            txt_oyna_upd.setText("Xaqiqiy o'rtacha harorat");
        }

        Button btn_oyna_back = (Button) dialog.findViewById(R.id.btn_oyna_back);
        Button btn_oyna_update = (Button) dialog.findViewById(R.id.btn_oyna_add);
        final EditText edt_oyna_upd = (EditText) dialog.findViewById(R.id.edt_oyna_xarorat);

        btn_oyna_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edt_oyna_upd.getText().toString().equals("")) {
                    String sa = "11";

                    float aa = Float.valueOf(edt_oyna_upd.getText().toString());
                    textView.setText(String.valueOf(aa));
                    if (yangi_add == 1) {
                        // yangi malumot qoshilgan bolsa
                        if (qator == 1) {
                            // 1 qator bolsa kop yillik ortacha harorat
                            int qaysi = all_sana.size() / 6;
                            if (!(qaysi >= 1)) {
                                // 1 ustun bolsa
                                if (!txt_foy_asosiy.getText().toString().equals("")) {
                                    float a_oldingi = Float.valueOf(txt_foy_asosiy.getText().toString());
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }
                                TextView textView = all_sana.get(kegingi);
                                textView.setText(String.valueOf(roundUp(aa, 1)));
                                dialog.dismiss();
                            } else {
                                // 2 ustun bolsa
                                TextView textView_oldingi = all_sana.get(kegingi - 6);
                                if (!textView_oldingi.getText().toString().equals("")) {
                                    float a_oldingi = Float.valueOf(textView_oldingi.getText().toString());
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }
                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);
                                TextView textView = all_sana.get(kegingi);
                                textView.setText(son);
                                dialog.dismiss();
                            }
                        } else if (qator == 2) {
                            // 2 qator bolsa  xaqiqiy ortacha harorat
                            int qaysi = all_sana.size() / 6;
                            if (!(qaysi >= 1)) {
                                // 1 ustun bolsa
                                if (!txt_foy_asosiy.getText().toString().equals("")) {
                                    float a_oldingi = Float.valueOf(txt_foy_asosiy.getText().toString());
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }
                                TextView textView = all_sana.get(kegingi);
                                textView.setText(String.valueOf(roundUp(aa, 1)));
                                TextView textView2 = all_sana.get(kegingi + 1);
                                textView2.setText(String.valueOf(roundUp(aa, 1)));
                                dialog.dismiss();
                            } else {
                                // 2 ustun bolsa
                                TextView textView_oldingi1 = all_sana.get(kegingi - 6);
                                String daas = textView_oldingi1.getText().toString();
                                if (!daas.equals("")) {
                                    float a_oldingi1 = Float.valueOf(daas);
                                    aa = (aa - ayir) + a_oldingi1;
                                } else {
                                    aa = (aa - ayir);
                                }
                                TextView textView = all_sana.get(kegingi);
                                String son = String.valueOf(roundUp(aa, 1));
                                textView.setText(son);

                                TextView textView2 = all_sana.get(kegingi + 1);
                                textView2.setText(String.valueOf(roundUp(aa, 1)));
                                dialog.dismiss();
                            }
                        } else {
                            // 1 ustun 1 qator bosilsa kop yillik ortacha harorat
                            if (qator == 5) {
                                txt_foy_asosiy.setText("0");
                                dialog.dismiss();
                            } else {
                                // 1 ustun 2 qator bosilsa xaqiqiy ortacha harorat
                                txt_yig_asosiy.setText("0");
                                txt_goza_asosiy.setText("0");
                                dialog.dismiss();
                            }
                        }
                        // ozgartirilganda
                    } else {
                        // 1 malumotni ozgartirganda kop yillik ortacha harorat
                        if (qator == 1) {
                            int qaysi = all_sana.size() / 7;
                            if (!(qaysi >= 1)) {
                                // 1 ustun bolsa
                                if (!oxir_foy.equals("")) {
                                    float a_oldingi = Float.valueOf(oxir_foy);
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }
                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);
                                TextView textView = all_sana.get(kegingi - qoshilgan_soni);
                                textView.setText(son);
                                dialog.dismiss();
                            } else {
                                // 2 ustun bolsa
                                TextView textView_oldingi = all_sana.get(kegingi - qoshilgan_soni - 6);
                                if (!textView_oldingi.getText().toString().equals("")) {
                                    float a_oldingi = Float.valueOf(textView_oldingi.getText().toString());
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }
                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);
                                TextView textView = all_sana.get(kegingi - qoshilgan_soni);
                                textView.setText(son);
                                dialog.dismiss();
                            }
                            // 2 qatorni ozgartirsa  xaqiqiy ortacha harorat
                        } else if (qator == 2) {
                            int qaysi = all_sana.size() / 7;
                            if (!(qaysi >= 1)) {
                                // 1 ustun bolsa
                                if (!oxir_yig.equals("")) {
                                    float a_oldingi = Float.valueOf(oxir_yig);
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }
                                String son = String.valueOf(roundUp(aa, 1));
                                TextView textView = all_sana.get(kegingi - qoshilgan_soni);
                                textView.setText(son);
                                TextView textView2 = all_sana.get(kegingi - qoshilgan_soni + 1);
                                textView2.setText(son);
                                dialog.dismiss();
                            } else {
                                // 2 ustun bolsa
                                TextView textView_oldingi1 = all_sana.get(kegingi - qoshilgan_soni - 6);
                                String daas = textView_oldingi1.getText().toString();
                                if (!daas.equals("")) {
                                    float a_oldingi1 = Float.valueOf(daas);
                                    aa = (aa - ayir) + a_oldingi1;
                                } else {
                                    aa = (aa - ayir);
                                }
                                String son = String.valueOf(roundUp(aa, 1));
                                TextView textView = all_sana.get(kegingi - qoshilgan_soni);
                                textView.setText(son);

                                TextView textView2 = all_sana.get(kegingi + 1 - qoshilgan_soni);
                                textView2.setText(son);
                                dialog.dismiss();
                            }
                        }
                    }
                }
            }
        });

        btn_oyna_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        int width = activity.getResources().getDisplayMetrics().widthPixels;
        int height = (int) (activity.getResources().getDisplayMetrics().heightPixels * 0.5);

//        dialog.getWindow().setLayout(width, height);
        dialog.show();

    }

    public BigDecimal roundUp(double value, int digits) {
        return new BigDecimal("" + value).setScale(digits, BigDecimal.ROUND_HALF_UP);
    }

    public void Sana_tanlash() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, dpickerListener, year_x, month_x, day_x);
        datePickerDialog.show();
    }

    private DatePickerDialog.OnDateSetListener dpickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(android.widget.DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            String oy, kun;
            if (monthOfYear < 10) {
                oy = "0" + String.valueOf(monthOfYear + 1) + ".";
            } else {
                oy = String.valueOf(monthOfYear + 1) + ".";
            }
            if (dayOfMonth < 10) {
                kun = "0" + String.valueOf(dayOfMonth) + ".";
            } else {
                kun = String.valueOf(dayOfMonth) + ".";
            }
            string12 = kun.toString() + oy.toString() + String.valueOf(year);
            txt_saaana.setText(string12);
        }
    };

    public void Qoshish_update(int id, String sana_, String kop, String foy, String xaq, String yig, String goza) {

        LayoutInflater inflater = (LayoutInflater) Goza_add.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        row_asosiy = inflater.inflate(R.layout.goza_add_items, null);

        TextView txt_goza_id = (TextView) row_asosiy.findViewById(R.id.txt_goza_id);
        txt_goza_id.setId(sana);
        txt_goza_id.setText(String.valueOf(id));
        all_eskilar.add(txt_goza_id);
        sana++;

        final TextView txt_sana = (TextView) row_asosiy.findViewById(R.id.txt_sana);
        txt_sana.setId(sana);
        txt_sana.setText(sana_);
        txt_sana.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_sana, 1);
                return true;
            }
        });
        all_eskilar.add(txt_sana);
        sana++;


        final TextView txt_kop = (TextView) row_asosiy.findViewById(R.id.txt_kop);
        txt_kop.setId(sana);
        txt_kop.setText(kop);
        txt_kop.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_kop, 2);
                return true;
            }
        });
        all_eskilar.add(txt_kop);
        sana++;

        final TextView txt_foy = (TextView) row_asosiy.findViewById(R.id.txt_foy);
        txt_foy.setId(sana);
        txt_foy.setText(foy);
        txt_foy.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_foy, 3);
                return true;
            }
        });
        all_eskilar.add(txt_foy);
        sana++;

        final TextView txt_xaq = (TextView) row_asosiy.findViewById(R.id.txt_xaq);
        txt_xaq.setId(sana);
        txt_xaq.setText(xaq);
        txt_xaq.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_xaq, 4);
                return true;
            }
        });
        all_eskilar.add(txt_xaq);
        sana++;

        final TextView txt_yig = (TextView) row_asosiy.findViewById(R.id.txt_yig);
        txt_yig.setId(sana);
        sana++;
        txt_yig.setText(yig);
        txt_yig.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_yig, 5);
                return true;
            }
        });
        all_eskilar.add(txt_yig);

        final TextView txt_goza = (TextView) row_asosiy.findViewById(R.id.txt_goza);
        txt_goza.setId(sana);
        txt_goza.setText(goza);
        txt_goza.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_goza, 6);
                return true;
            }
        });
        all_eskilar.add(txt_goza);
        sana++;

        gridLayout.addView(row_asosiy, indexx);
        indexx++;
    }

    public void Qoshish() {
        View row;
        LayoutInflater inflater = (LayoutInflater) Goza_add.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        row = inflater.inflate(R.layout.goza_add_items, null);

        final TextView txt_sana = (TextView) row.findViewById(R.id.txt_sana);
        txt_sana.setId(sana);
        if (!string12.equals("")) {
            string12 = Kegingi_sana(string12);
        }
        txt_sana.setText(string12);
        txt_sana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_saaana = txt_sana;
                Sana_tanlash();
            }
        });
        txt_sana.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_sana, 1);
                return true;
            }
        });
        all_sana.add(txt_sana);
        sana++;


        final TextView txt_kop = (TextView) row.findViewById(R.id.txt_kop);
        txt_kop.setId(sana);
        txt_kop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_OnClick(txt_kop, 1);
            }
        });

        txt_kop.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_kop, 2);
                return true;
            }
        });
        all_sana.add(txt_kop);
        sana++;

        final TextView txt_foy = (TextView) row.findViewById(R.id.txt_foy);
        txt_foy.setId(sana);
        txt_foy.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_foy, 3);
                return true;
            }
        });
        all_sana.add(txt_foy);
        sana++;

        final TextView txt_xaq = (TextView) row.findViewById(R.id.txt_xaq);
        txt_xaq.setId(sana);
        txt_xaq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_OnClick(txt_xaq, 2);
            }
        });
        txt_xaq.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_xaq, 4);
                return true;
            }
        });
        sana++;
        all_sana.add(txt_xaq);

        final TextView txt_yig = (TextView) row.findViewById(R.id.txt_yig);
        txt_yig.setId(sana);
        txt_yig.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_yig, 5);
                return true;
            }
        });
        sana++;
        all_sana.add(txt_yig);

        final TextView txt_goza = (TextView) row.findViewById(R.id.txt_goza);
        txt_goza.setId(sana);
        txt_goza.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_goza, 6);
                return true;
            }
        });
        sana++;
        all_sana.add(txt_goza);

        gridLayout.addView(row, indexx);

        scrollView.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (indexx > 4) {
                    scrollView.fullScroll(HorizontalScrollView.FOCUS_RIGHT);
                }
            }
        }, 100L);
        indexx++;
    }

    public String Kegingi_sana(String old_date) {

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdf.parse(old_date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //Incrementing the date by 1 day
        c.add(Calendar.DAY_OF_MONTH, 1);
        return sdf.format(c.getTime());
    }

    public String Oldingi_sana(String old_date) {

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdf.parse(old_date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //Incrementing the date by 1 day
        c.add(Calendar.DAY_OF_MONTH, -1);
        return sdf.format(c.getTime());
    }

    public void Xabar_chiqarish(String son) {

        SharedPreferences preferences = getSharedPreferences("setting", Context.MODE_PRIVATE);

        String goza = preferences.getString("xabar", "1");
        if (goza.equals("1")) {

            int son_solish = (int) Float.parseFloat(son);
            if (son_solish > 30 && son_solish < 50) {
                Xabar_korsatish("50 ga yetganda tuxum qo'yish boshlanadi!");
            } else if (son_solish > 180 && son_solish < 200) {
                Xabar_korsatish("200 ga yetganda 2 yosh qurtlari!");
            } else if (son_solish > 220 && son_solish < 250) {
                Xabar_korsatish("250 ga yetganda 4 yosh qurtlari!");
            } else if (son_solish > 370 && son_solish < 400) {
                Xabar_korsatish("400 ga yetganda 6 yosh qurtlari!");
            } else if (son_solish > 520 && son_solish < 550) {
                Xabar_korsatish("550 ga yetganda rivojlanish tugadi!");
            } else if (son_solish > 570 && son_solish < 600) {
                Xabar_korsatish("600 ga yetganda 1 paxta avlodi tuxum qo'yadi!");
            } else if (son_solish > 720 && son_solish < 750) {
                Xabar_korsatish("750 ga yetganda 2 yosh qurtlari!");
            } else if (son_solish > 800 && son_solish < 850) {
                Xabar_korsatish("850 ga yetganda 4 yosh qurtlari!");
            } else if (son_solish > 900 && son_solish < 950) {
                Xabar_korsatish("950 ga yetganda 6 yosh qurtlari!");
            } else if (son_solish > 1050 && son_solish < 1100) {
                Xabar_korsatish("1100 ga yetganda rivojlanish tugadi!");
            } else if (son_solish > 1120 && son_solish < 1150) {
                Xabar_korsatish("1150 ga yetganda 2-paxta avlodi tuxum qo'yadi!");
            } else if (son_solish > 1280 && son_solish < 1300) {
                Xabar_korsatish("1300 ga yetganda 2 yosh qurtlari");
            } else if (son_solish > 1370 && son_solish < 1400) {
                Xabar_korsatish("1400 ga yetganda 4 yosh qurtlari");
            } else if (son_solish > 1470 && son_solish < 1500) {
                Xabar_korsatish("1500 ga yetganda 6 yosh qurtlari");
            } else if (son_solish > 1600 && son_solish < 1650) {
                Xabar_korsatish("1650 ga yetganda rivojlanish tugadi!");
            }

        }
    }

    Context context = Goza_add.this;

    public void Xabar_korsatish(String xabar) {

        NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.gozaic)
                .setContentTitle("G'o'za va g'o'za tunlami")
                .setContentText(xabar)
                .setSound(alarmSound)
                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(),
                        R.drawable.goza_32))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        id++;
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(id, mBuilder.build());

        final AlertDialog.Builder adb = new AlertDialog.Builder(this);
        adb.setMessage(xabar);
        adb.setIcon(R.drawable.goza_32);
        adb.setTitle("Ogohlantirish");
        adb.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        adb.show();
    }

}
